#!/bin/bash

# Директория назначения для резервной копии
BACKUP_DIR="~/petsweb_backup"

# Создание каталога назначения
mkdir -p $BACKUP_DIR

# Копирование с параметром --delete для синхронизации
touch ~/petsweb_backup/suvaline.txt  # Пример добавления лишнего файла
sudo rsync -avh --delete \
--exclude="*.md" \
--exclude="package.json" \
--exclude="install.sh" \
--exclude="tests/" \
/var/www/petsweb/ $BACKUP_DIR/

# Проверка результата
echo "--- SIHTKOHA STRUKTUUR (PÄRAST 2. SYNC) ---"
ls -lR $BACKUP_DIR
