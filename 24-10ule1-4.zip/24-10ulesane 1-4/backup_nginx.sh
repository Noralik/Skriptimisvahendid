#!/bin/bash

# Директория назначения для резервной копии
BACKUP_DIR="~/petsweb_backup"

# Создание каталога назначения
mkdir -p $BACKUP_DIR

# Выполнение симуляции резервного копирования
sudo rsync -avhn /var/www/petsweb/ $BACKUP_DIR/

# Выполнение реального копирования с исключениями
sudo rsync -avh \
--exclude="*.md" \
--exclude="package.json" \
--exclude="install.sh" \
--exclude="tests/" \
/var/www/petsweb/ $BACKUP_DIR/

# Проверка результата
echo "--- SIHTKOHA STRUKTUUR (PÄRAST 1. SYNC) ---"
ls -lR $BACKUP_DIR
