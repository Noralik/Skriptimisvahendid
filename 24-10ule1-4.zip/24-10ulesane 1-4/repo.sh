#!/bin/bash

# Лог-файл для отчета
LOG_FILE="ngx_logreport_$(date +'%Y-%m-%d_%H%M%S').log"

# Записываем заголовок в лог
echo "--- NGINXI LOGIDE ANALÜÜS ---" > $LOG_FILE

# Добавляем информацию о активных процессах nginx
echo "" >> $LOG_FILE
echo "--- AKTIIVSED NGINXI PROTSESSID ---" >> $LOG_FILE
ps aux | grep nginx >> $LOG_FILE

# Добавляем ошибки 404
echo "" >> $LOG_FILE
echo "--- LEITUD 404 VEAD (access.log) ---" >> $LOG_FILE
sudo cat /var/log/nginx/access.log | grep " 404 " >> $LOG_FILE

# Добавляем количество ошибок 404
echo "" >> $LOG_FILE
echo "--- 404 VIGADE KOGUARV ---" >> $LOG_FILE
sudo cat /var/log/nginx/access.log | grep " 404 " | wc -l >> $LOG_FILE

# Добавляем критические ошибки
echo "" >> $LOG_FILE
echo "--- KRIITILISED VEAD (error.log) ---" >> $LOG_FILE
sudo cat /var/log/nginx/error.log | grep "crit" >> $LOG_FILE

# Заключение отчета
echo "" >> $LOG_FILE
echo "--- ANALÜÜSI LÕPP ---" >> $LOG_FILE

# Выводим результат
cat $LOG_FILE
