#!/bin/bash
#
# NAME: task_1_status_check.sh
# AUTHOR: SPECTER
# DATE: 2025-10-16
# COMPANY: TTHK
#
# DESCRIBTION: log fail webtest YYYY-MM-DD_HH-MM-SS
#

#
URL="http://Skapec/"
TIME=$(date +%Y%m%d_%H%M%S)
LOGFILE="webtest_${TIME}.log"

echo "WEB TEST LOG - ${TIME}" > "${LOGFILE}"
echo "URL: ${URL}" >> "${LOGFILE}"
echo "-------------------------------" >> "${LOGFILE}"

HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" "${URL}")

TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S')
if [ "${HTTP_CODE}" = "200" ]; then
    echo "${TIMESTAMP} - ${URL} - ${HTTP_CODE} - VERY GOOD" | tee -a "${LOGFILE}"
    exit 0
else
    echo "${TIMESTAMP} - ${URL} - ${HTTP_CODE} - Error" | tee -a "${LOGFILE}"
    exit 1
fi
