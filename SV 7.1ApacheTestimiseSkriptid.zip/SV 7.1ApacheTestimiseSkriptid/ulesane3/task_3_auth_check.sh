#!/bin/bash
#
# NAME: task_3_auth_check.sh
# AUTHOR: SPECTER
# DATE: 2025-10-16
# COMPANY: TTHK
#
# DESCRIBTION: log fail basic auth test with curl on https://Skapec/secure/
#

URL="https://Skapec/secure/"
TIME=$(date +%Y%m%d_%H%M%S)
LOGFILE="auth_test_${TIME}.log"

echo "AUTH TEST LOG - ${TIME}" > "${LOGFILE}"
echo "URL: ${URL}" >> "${LOGFILE}"
echo "-------------------------------" >> "${LOGFILE}"

test_auth() {
    local creds="$1"
    local expect="$2"

    if [ -n "$creds" ]; then
        HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" -u "$creds" "$URL")
    else
        HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" "$URL")
    fi

    TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S')

    if [ "$HTTP_CODE" = "$expect" ]; then
        echo "${TIMESTAMP} - creds='${creds:-<none>}' - expected=${expect} - got=${HTTP_CODE} - VERY GOOD" | tee -a "${LOGFILE}"
    else
        echo "${TIMESTAMP} - creds='${creds:-<none>}' - expected=${expect} - got=${HTTP_CODE} - Error" | tee -a "${LOGFILE}"
    fi
}

test_auth "" "401"

test_auth "user:correctpass" "200"

test_auth "user:wrongpass" "401"
