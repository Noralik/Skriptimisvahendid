#!/bin/bash
#
# NAME: task_2_redirect_check.sh
# AUTHOR: SPECTER
# DATE: 2025-10-16
# COMPANY: TTHK
#
# DESCRIBTION: log fail redirect test from http to https with Location header

URL="http://Skapec/"
TIME=$(date +%Y%m%d_%H%M%S)
LOGFILE="redirect_test_${TIME}.log"

echo "REDIRECT TEST LOG - ${TIME}" > "${LOGFILE}"
echo "URL: ${URL}" >> "${LOGFILE}"
echo "-------------------------------" >> "${LOGFILE}"

RESP_HEADERS=$(curl -s -D - -o /dev/null "${URL}")

LOCATION=$(printf "%s" "${RESP_HEADERS}" | grep -i '^Location:' | sed -E 's/Location:[[:space:]]*//I' | tr -d '\r')
HTTP_CODE=$(printf "%s" "${RESP_HEADERS}" | grep -i '^HTTP/' | tail -n1 | awk '{print $2}')

TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S')

if [ -n "${LOCATION}" ]; then
    echo "${TIMESTAMP} - ${URL} - HTTP_CODE: ${HTTP_CODE} - Location: ${LOCATION}" | tee -a "${LOGFILE}"
    if printf "%s" "${LOCATION}" | grep -qi '^https://'; then
        echo "${TIMESTAMP} - Redirect to HTTPS - VERY GOOD" | tee -a "${LOGFILE}"
        exit 0
    else
        echo "${TIMESTAMP} - Redirect Location is not HTTPS - Error" | tee -a "${LOGFILE}"
        exit 1
    fi
else
    echo "${TIMESTAMP} - No Location header - Redirect not found - Error" | tee -a "${LOGFILE}"
    exit 1
fi
